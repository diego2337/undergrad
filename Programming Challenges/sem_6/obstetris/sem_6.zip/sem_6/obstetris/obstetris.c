#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef struct 
{
	int score;
	char nome[310];
	char sobrenome[310];
} tetris;

int compare (const void * a, const void * b)
{
  return ( *(int*)b - *(int*)a );
}

int compare_str (const void * a, const void * b)
{
	tetris aux = *(tetris *) a;
	tetris aux2 = *(tetris *) b;

	if (aux.score != aux2.score) return aux.score - aux2.score;
	if (strcmp (aux.nome, aux2.nome) != 0) return strcmp (aux.nome, aux2.nome);
	return strcmp( aux.sobrenome, aux2.sobrenome );
} 



int main(void)
{
	int J, i, k, max, min, aux;
	tetris players[310];
	char c;
	scanf("%d", &J);
	c = getchar();
	while(J != 0)
	{
		c = getchar();
		for(i = 0; i < J; i++)
			players[i].score = 0;
		for(i = 0; i < J; i++)
		{
			k = 0;
			max = 0;
			min = 10000000;
			while(c != ' ' && c != EOF && !isdigit(c))
			{
				players[i].nome[k] = c;
				k++;
				c = getchar();
			}
			c = getchar();
			k = 0;
			while(c != '\n' && c != EOF && !isdigit(c))
			{
				players[i].sobrenome[k] = c;
				k++;
				c = getchar();
			}
			for(k = 0; k < 12; k++)
			{
				scanf("%d", &aux);
				if(aux > max)
					max = aux;
				if(aux < min)
					min = aux;
				players[i].score = players[i].score + aux;
			}	
			players[i].score = players[i].score - max - min;	
			printf("final score %d\n", players[i].score);
			c = getchar();
			c = getchar();
		}
		for(i = 0; i < 4; i++)
		{
			printf("%d %s\n", players[i].score, players[i].nome);
		}
		puts("--------------ordenei");
		qsort(players, J, sizeof(tetris), compare_str);
		for(i = 0; i < 4; i++)
		{
			printf("%d %s\n", players[i].score, players[i].nome);
		}
		printf("\n");
		exit(0);
		scanf("%d", &J);
		c = getchar();
	}
	return 0;
}