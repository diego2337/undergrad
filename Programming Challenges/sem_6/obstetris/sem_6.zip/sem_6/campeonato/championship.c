#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int match_team(char team[31], char teams[31][31], int T)
{
	int i;
	for(i = 0; i < T; i++)
	{
		if(strcmp(team, teams[i]) == 0)
		{
			return i;
		}
	}
	return -1;
}

int main(void)
{
	int N, T, G, i, j, k, goals[31], points[31], games[31], victories[31], ties[31], defeats[31], saldo[31], pro_goals[31], contra_goals[31];
	char cups[1000][100], teams[31][31], team[31], c;
	scanf("%d", &N);
	for(i = 0; i < N; i++)
	{
		scanf("%s", cups[i]);
		scanf("%d", &T);
		for(j = 0; j < T; j++)
		{
			scanf("%s", teams[j]);
		}
		scanf("%d", &G);
		for(j = 0; j < G; j++)
		{
			c = getchar();
			k = 0;
			while(c != '#')
			{
				team[k] = c;
				k++;
				c = getchar();
			}
			k = match_team(team, teams, T);
			goals[k] = goals[k] + 1;
			
			printf("%s", team);
		}
	}
	return 0;
}