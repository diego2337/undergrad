// Arquivo: DoubleList.h
// Implementa��o de listas duplamente encadeadas usando templates.
// Exig�ncias para instanciar uma Lista DoubleList utilizando o template abaixo:
//	- O tipo T deve especificar o construtor vazio: T() (usado no primeiro construtor de DoubleNode)
//	- O tipo T ter implementado o operador ==
// Obs: o ctor DoubleNode(const T& el, DoubleNode *ptr=0, DoubleNode *ptr2=0) utilizar� o construtor de c�pia de T (implementado ou fornecido pelo compilador) para cria��o e inicializa��o de info. Repare a sintaxe deste construtor;
// Uma alternativa � utilizar a vers�o comentada do construtor onde um operador de c�pia � utilizado. Nesse caso, T deve ter implementado um operador de 
// c�pia ou ser� utilizado o operador de c�pia rasa fornecido pelo compilador.



#ifndef _DOUBLELIST_H
#define _DOUBLELIST_H

#include <iostream>
#include <stdlib.h>

using std::cout;
using std::endl;


template <typename T>
class DoubleNode
{
	public:
		DoubleNode()
		{
			next = prev = 0;
		}

		DoubleNode(const T& el, DoubleNode *ptr=0, DoubleNode *ptr2=0):
 		info(el)
		{
			this->next = ptr;
			this->prev = ptr2;
		}
		
		T info;
		DoubleNode* next;
		DoubleNode* prev;
};


template <typename T>
class DoubleList
{
	public:
		DoubleList()
		{
			head = tail = 0;
			numberOfNodes = 0;
		}

	    ~DoubleList();

		bool isEmpty() const
		{
			return head == 0;
	    }
		bool contains(const T& element) const
		{
			return isInList(element) != 0;
		}
	 	void addHead(const T&);
		void addTail(const T&);
		void deleteHead();   
		void deleteTail();   
		void deleteNode(const T&);
		void print() const;
		int size() const;
                

	private:

		DoubleNode<T>* isInList(const T&) const;

		DoubleNode<T> *head, *tail;
		int numberOfNodes;
};

template <typename T>
DoubleList<T>::~DoubleList()
{
	DoubleNode<T> *p;
	while(!isEmpty())
	{
		p = head->next;
		delete head;
		head = p;
	}
	numberOfNodes = 0;
}

template <typename T>
void DoubleList<T>::addHead (const T& newElement)
{
	DoubleNode<T> *newNode = new DoubleNode<T>(newElement, head, 0);
	if(newNode == 0)
	{
		throw DoubleListException(0);
	}
	if(isEmpty())
	{
		tail = newNode;
	}
	else
	{
		head->prev = newNode;
	}
	head = newNode;
	numberOfNodes++;

}



template <typename T>
void DoubleList<T>::addTail (const T& newElement)
{
	DoubleNode<T> *newNode = new DoubleNode<T>(newElement, 0, tail);
	if(newNode == 0)
	{
		throw DoubleListException(0);
	}
	if(isEmpty())
	{
		head = newNode;
	}
	else
	{
		tail->next = newNode;
	}
	tail = newNode;
	numberOfNodes++;
}


template <typename T>
void DoubleList<T>::deleteHead ()
{
	if(isEmpty())
	{
		throw DoubleListException(1);
	}
	else
	{
		DoubleNode<T> *temp = head;
		head = head->next;
		if(head)
		{
			head->prev = 0;
		}
		else
		{
			tail = 0;
		}
		numberOfNodes--;
		delete temp;
	}
	
}

template <typename T>
void DoubleList<T>::deleteTail ()
{
	if(isEmpty())
	{
		throw DoubleListException(1);
	}
	else
	{
		DoubleNode<T> *temp = tail;
		tail = tail->prev;
		if(tail)
		{
			tail->next = 0;
		}
		else
		{
			head = 0;
		}
		numberOfNodes--;
		delete temp;
	}


}

template <typename T>
void DoubleList<T>::deleteNode (const T& element)
{
	DoubleNode<T> *f = isInList(element);
	if(f == 0)
		throw DoubleListException(2);
	else
	{
		if(f == tail)
			deleteTail();
		if(f == head)
			deleteHead();
		else
		{
			f->prev->next = f->next;
			f->next->prev = f->prev;
			numberOfNodes--;
			delete f;
		}
	}

		
	
}

template <typename T>
DoubleNode<T>* DoubleList<T>::isInList (const T& element) const
{
	DoubleNode<T> *aux = head;
	while(aux != 0)
	{
		if(aux->info == element)
			return aux;
		else
		{
			aux = aux->next;
		}
	}
	return 0;

	/* Poderia ser feito da seguinte maneira:
		DoubleNode<T> *tmp;
		for(tmp=head; tmp!=0 && !(tmp->info==element); tmp=tmp->next)

		return tmp;*/
}




template <typename T>
void DoubleList<T>::print() const
{
	DoubleNode<T> *aux = head;
	while(aux != 0)
	{
		cout << aux->info << " ";
		aux = aux->next;
	}
	cout << "\n";

	/*Poderia ser feito:
		DoubleNode<T> *tmp;
		cout << "Quantidade de elementos: " << size();
		for(tmp = head; tmp != 0; tmp = tmp->next)
			cout << tmp->info << " ";*/

}


template <typename T>
inline
int DoubleList<T>::size() const
{
	return numberOfNodes;
}

#endif
